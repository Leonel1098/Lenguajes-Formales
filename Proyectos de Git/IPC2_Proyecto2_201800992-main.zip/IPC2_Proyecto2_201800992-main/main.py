from tkinter import Tk
from Interface import *
if __name__ == '__main__':
    ventana = Tk()
    app = interface(ventana)
    ventana.mainloop()