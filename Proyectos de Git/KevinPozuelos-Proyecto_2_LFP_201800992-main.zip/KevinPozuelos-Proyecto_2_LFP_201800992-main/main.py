from Menu import *
if __name__ == '__main__':
    pri = PantallaInicial()
    menu = menuP()