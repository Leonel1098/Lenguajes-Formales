class Dato:
    def __init__(self, x, y, val, accessM):
        self.x = x
        self.y = y
        self.value = val
        self.accessM = accessM
        self.next = None