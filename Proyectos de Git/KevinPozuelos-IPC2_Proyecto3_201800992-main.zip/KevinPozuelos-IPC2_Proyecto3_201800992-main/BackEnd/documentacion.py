import os
class documentacion:

    def abrirdocumetacion(self):
        os.startfile("Documentacion.pdf")